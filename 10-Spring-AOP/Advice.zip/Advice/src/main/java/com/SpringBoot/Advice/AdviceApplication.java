package com.SpringBoot.Advice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdviceApplication.class, args);
	}

}
